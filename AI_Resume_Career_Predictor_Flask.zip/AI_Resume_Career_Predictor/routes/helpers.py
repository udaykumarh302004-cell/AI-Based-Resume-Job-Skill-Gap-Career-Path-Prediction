"""
Shared helpers used by multiple blueprints.
"""
from flask import flash, redirect, url_for
from flask_login import current_user

from extensions import db
from models import Resume, ExtractedSkill
from modules.skill_extractor import user_skill_map


def get_latest_resume(user=None):
    user = user or current_user
    return (
        Resume.query.filter_by(user_id=user.id)
        .order_by(Resume.created_at.desc())
        .first()
    )


def get_user_skills(user=None):
    """
    Returns ({skill: proficiency}, latest_resume or None).
    Uses the most recent resume's extracted skills.
    """
    resume = get_latest_resume(user)
    if not resume:
        return {}, None
    rows = ExtractedSkill.query.filter_by(resume_id=resume.id).all()
    return user_skill_map(rows), resume


def require_skills_or_redirect():
    """Guard: analysis features need an uploaded resume first."""
    skills, resume = get_user_skills()
    if not resume or not skills:
        flash("Please upload and parse a resume first so we can analyze your skills.", "warning")
        return None, redirect(url_for("resume.upload"))
    return (skills, resume), None


def admin_required(f):
    """Decorator: allow admins only."""
    import functools

    @functools.wraps(f)
    def wrapper(*args, **kwargs):
        if not current_user.is_authenticated:
            flash("Please log in to access this page.", "warning")
            return redirect(url_for("auth.login"))
        if current_user.role != "admin":
            flash("Admin access required.", "danger")
            return redirect(url_for("main.index"))
        return f(*args, **kwargs)

    return wrapper
