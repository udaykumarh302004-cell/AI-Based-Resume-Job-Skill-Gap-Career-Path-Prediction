"""
Module 1 : User Registration & Login
"""
from flask import Blueprint, render_template, request, redirect, url_for, flash
from flask_login import login_user, logout_user, login_required, current_user

from extensions import db
from models import User, log_activity

auth_bp = Blueprint("auth", __name__)


@auth_bp.route("/register", methods=["GET", "POST"])
def register():
    if current_user.is_authenticated:
        return redirect(url_for("main.index"))

    if request.method == "POST":
        name = (request.form.get("name") or "").strip()
        email = (request.form.get("email") or "").strip().lower()
        password = request.form.get("password") or ""
        confirm = request.form.get("confirm_password") or ""

        errors = []
        if len(name) < 2:
            errors.append("Please enter your full name.")
        if "@" not in email or "." not in email or len(email) < 6:
            errors.append("Please enter a valid email address.")
        if len(password) < 6:
            errors.append("Password must be at least 6 characters long.")
        if password != confirm:
            errors.append("Passwords do not match.")
        if not errors and User.query.filter_by(email=email).first():
            errors.append("An account with this email already exists. Please log in.")

        if errors:
            for e in errors:
                flash(e, "danger")
            return render_template("auth/register.html", name=name, email=email)

        user = User(name=name, email=email, role="user")
        user.set_password(password)
        db.session.add(user)
        db.session.commit()

        log_activity(user, "registration", f"New user registered: {email}")
        flash("Registration successful! Please log in.", "success")
        return redirect(url_for("auth.login"))

    return render_template("auth/register.html")


@auth_bp.route("/login", methods=["GET", "POST"])
def login():
    if current_user.is_authenticated:
        return redirect(url_for("dashboard.index"))

    if request.method == "POST":
        email = (request.form.get("email") or "").strip().lower()
        password = request.form.get("password") or ""
        remember = bool(request.form.get("remember"))

        user = User.query.filter_by(email=email).first()
        if user is None or not user.check_password(password):
            flash("Invalid email or password.", "danger")
            return render_template("auth/login.html", email=email)
        if not user.is_active:
            flash("Your account has been deactivated. Contact the administrator.", "danger")
            return render_template("auth/login.html", email=email)

        login_user(user, remember=remember)
        log_activity(user, "login", "User logged in")
        flash(f"Welcome back, {user.name.split()[0]}!", "success")

        next_page = request.args.get("next")
        if next_page and next_page.startswith("/"):
            return redirect(next_page)
        if user.role == "admin":
            return redirect(url_for("admin.dashboard"))
        return redirect(url_for("dashboard.index"))

    return render_template("auth/login.html")


@auth_bp.route("/logout")
@login_required
def logout():
    log_activity(current_user, "logout", "User logged out")
    logout_user()
    flash("You have been logged out.", "info")
    return redirect(url_for("main.index"))


@auth_bp.route("/profile")
@login_required
def profile():
    from models import GapAnalysis, LearningPathRecord, CareerPrediction, Resume

    resumes = Resume.query.filter_by(user_id=current_user.id).order_by(Resume.created_at.desc()).all()
    gaps = GapAnalysis.query.filter_by(user_id=current_user.id).order_by(GapAnalysis.created_at.desc()).limit(5).all()
    lps = LearningPathRecord.query.filter_by(user_id=current_user.id).order_by(LearningPathRecord.created_at.desc()).limit(5).all()
    preds = CareerPrediction.query.filter_by(user_id=current_user.id).order_by(CareerPrediction.created_at.desc()).limit(5).all()
    return render_template("auth/profile.html", resumes=resumes, gaps=gaps, lps=lps, preds=preds)
