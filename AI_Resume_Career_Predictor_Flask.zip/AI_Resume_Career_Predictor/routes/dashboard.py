"""
Module 11 : Dashboard & Visualization
-------------------------------------
Aggregates the user's skill, match and history data into Chart.js charts.
"""
from flask import Blueprint, render_template, redirect, url_for, flash
from flask_login import current_user, login_required

from extensions import db
from models import Resume, ExtractedSkill, GapAnalysis, Job, LearningPathRecord, CareerPrediction
from modules.job_recommender import recommend_jobs
from routes.helpers import get_user_skills

dashboard_bp = Blueprint("dashboard", __name__)


@dashboard_bp.route("/dashboard")
@login_required
def index():
    skills, resume = get_user_skills()
    if not resume or not skills:
        flash("Upload your resume to activate your personalized dashboard.", "info")
        return redirect(url_for("resume.upload"))

    rows = ExtractedSkill.query.filter_by(resume_id=resume.id).order_by(ExtractedSkill.proficiency.desc()).all()

    # ---- chart 1: skills by category (doughnut) --------------------------
    cat_counts = {}
    for r in rows:
        cat_counts[r.category] = cat_counts.get(r.category, 0) + 1
    cat_labels = list(cat_counts.keys())
    cat_values = list(cat_counts.values())

    # ---- chart 2: top job matches (bar) ----------------------------------
    jobs = Job.query.filter_by(is_active=True).all()
    ranked = recommend_jobs(skills, jobs)[:8]
    match_labels = [f'{r["job"].title}' for r in ranked]
    match_values = [r["match"] for r in ranked]
    best_match = ranked[0] if ranked else None

    # ---- chart 3: skill readiness radar (top skills) ---------------------
    radar_labels = [r.skill_name for r in rows[:8]]
    radar_values = [r.proficiency for r in rows[:8]]

    # ---- history line: match % over time ---------------------------------
    history = (GapAnalysis.query.filter_by(user_id=current_user.id)
               .order_by(GapAnalysis.created_at.asc()).limit(12).all())
    hist_labels = [h.job_title[:22] for h in history]
    hist_values = [h.match_percentage for h in history]

    # ---- learning paths + predictions ------------------------------------
    lps = (LearningPathRecord.query.filter_by(user_id=current_user.id)
           .order_by(LearningPathRecord.created_at.desc()).limit(4).all())
    preds = (CareerPrediction.query.filter_by(user_id=current_user.id)
             .order_by(CareerPrediction.created_at.desc()).first())

    gaps = (GapAnalysis.query.filter_by(user_id=current_user.id)
            .order_by(GapAnalysis.created_at.desc()).limit(6).all())

    stats = {
        "resumes": Resume.query.filter_by(user_id=current_user.id).count(),
        "skills": len(rows),
        "avg_proficiency": round(sum(r.proficiency for r in rows) / len(rows), 1) if rows else 0,
        "analyses": GapAnalysis.query.filter_by(user_id=current_user.id).count(),
        "best_match": best_match["match"] if best_match else 0,
        "jobs_available": len(jobs),
        "avg_match": round(sum(r["match"] for r in ranked) / len(ranked), 1) if ranked else 0,
    }

    return render_template(
        "dashboard/index.html",
        resume=resume, rows=rows, stats=stats,
        cat_labels=cat_labels, cat_values=cat_values,
        match_labels=match_labels, match_values=match_values,
        best_match=best_match,
        radar_labels=radar_labels, radar_values=radar_values,
        hist_labels=hist_labels, hist_values=hist_values,
        ranked=ranked[:5], gaps=gaps, lps=lps, preds=preds,
    )
