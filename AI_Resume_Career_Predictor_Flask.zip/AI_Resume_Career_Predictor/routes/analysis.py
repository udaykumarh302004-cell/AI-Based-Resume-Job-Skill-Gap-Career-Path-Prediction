"""
Module 5 : Skill Matching & Gap Analysis
Module 6 : Skill Gap Recommendation
Module 7 : Career Path Prediction
Module 8 : Job Role Recommendation
Module 9 : Personalized Learning Path
"""
from flask import Blueprint, render_template, request, redirect, url_for, flash, abort
from flask_login import current_user, login_required

from extensions import db
from models import GapAnalysis, CareerPrediction, LearningPathRecord, Job, log_activity
from modules.gap_analyzer import score_match, build_recommendations
from modules.career_predictor import predict_career_path, next_step_resources
from modules.role_recommender import recommend_roles
from modules.learning_path import generate_learning_path
from routes.helpers import get_user_skills, require_skills_or_redirect

analysis_bp = Blueprint("analysis", __name__)


# ==========================================================================
# Module 5 : Gap Analysis
# ==========================================================================
@analysis_bp.route("/gap-analysis", methods=["GET", "POST"])
@login_required
def gap():
    guard = require_skills_or_redirect()
    if guard[1]:
        return guard[1]
    (user_skills, resume) = guard[0]

    jobs = Job.query.filter_by(is_active=True).order_by(Job.title).all()
    past = (GapAnalysis.query.filter_by(user_id=current_user.id)
            .order_by(GapAnalysis.created_at.desc()).limit(10).all())

    if request.method == "POST":
        job_id = request.form.get("job_id", type=int)
        job = db.session.get(Job, job_id) if job_id else None
        if job is None or not job.skills_json:
            flash("Please choose a job with extracted skills to run the gap analysis.", "warning")
            return redirect(url_for("analysis.gap"))

        result = score_match(user_skills, job.skills_json)
        record = GapAnalysis(
            user_id=current_user.id,
            job_id=job.id,
            job_title=job.title,
            company=job.company,
            match_percentage=result["match_percentage"],
            verdict=result["verdict"],
            matched_skills=result["matched"] + [
                dict(m) for m in result["matched_via"]
            ],
            missing_skills=result["missing"],
            additional_skills=result["additional"][:15],
        )
        db.session.add(record)
        db.session.commit()
        log_activity(current_user, "gap_analysis",
                     f"{result['match_percentage']}% match for {job.title}")
        flash("Gap analysis complete!", "success")
        return render_template("analysis/gap_result.html", result=result, job=job, record=record, resume=resume)

    return render_template("analysis/gap_select.html", jobs=jobs, past=past, resume=resume)


@analysis_bp.route("/gap-analysis/result/<int:record_id>")
@login_required
def gap_result(record_id):
    record = db.session.get(GapAnalysis, record_id)
    if record is None:
        abort(404)
    if record.user_id != current_user.id and current_user.role != "admin":
        abort(403)

    job = db.session.get(Job, record.job_id) if record.job_id else None
    # rebuild a light "result" view from stored JSON
    result = {
        "match_percentage": record.match_percentage,
        "verdict": record.verdict,
        "verdict_class": "primary",
        "matched": [m for m in (record.matched_skills or []) if not m.get("via")],
        "matched_via": [m for m in (record.matched_skills or []) if m.get("via")],
        "missing": record.missing_skills or [],
        "additional": record.additional_skills or [],
        "total_required": len(record.matched_skills or []) + len(record.missing_skills or []),
        "matched_count": len(record.matched_skills or []),
        "missing_count": len(record.missing_skills or []),
    }
    if record.match_percentage >= 80:
        result["verdict_class"] = "success"
    elif record.match_percentage >= 60:
        result["verdict_class"] = "primary"
    elif record.match_percentage >= 40:
        result["verdict_class"] = "warning"
    else:
        result["verdict_class"] = "danger"
    return render_template("analysis/gap_result.html", result=result, job=job, record=record, resume=None)


# ==========================================================================
# Module 6 : Skill gap recommendations (for a stored analysis)
# ==========================================================================
@analysis_bp.route("/gap-recommendations/<int:record_id>")
@login_required
def gap_recommendations(record_id):
    record = db.session.get(GapAnalysis, record_id)
    if record is None:
        abort(404)
    if record.user_id != current_user.id and current_user.role != "admin":
        abort(403)

    missing = record.missing_skills or []
    recs = build_recommendations(missing, record.job_title or "this role")
    high = [r for r in recs if r["priority"] == "High"]
    return render_template("analysis/recommendations.html", record=record, recs=recs, high=high)


# ==========================================================================
# Module 7 : Career Path Prediction
# ==========================================================================
@analysis_bp.route("/career-path", methods=["GET"])
@login_required
def career_path():
    guard = require_skills_or_redirect()
    if guard[1]:
        return guard[1]
    (user_skills, resume) = guard[0]

    prediction = predict_career_path(user_skills, resume.experience_years or 0)
    resources = next_step_resources(prediction["next_missing"])

    record = CareerPrediction(
        user_id=current_user.id,
        best_track=prediction["best_track"],
        current_level_title=prediction["current_title"],
        next_level_title=prediction["next_title"],
        predictions={
            "best_track": prediction["best_track"],
            "current_title": prediction["current_title"],
            "next_title": prediction["next_title"],
            "top_roles": prediction["top_roles"],
            "ladder_readiness": [{ "title": s["title"], "readiness": s["readiness"], "level": s["level"]} for s in prediction["ladder"]],
        },
    )
    db.session.add(record)
    db.session.commit()
    log_activity(current_user, "career_prediction",
                 f"Track: {prediction['best_track']} | Next: {prediction['next_title']}")

    return render_template("analysis/career.html", prediction=prediction,
                           resources=resources, record=record, resume=resume)


# ==========================================================================
# Module 8 : Job Role Recommendation
# ==========================================================================
@analysis_bp.route("/role-recommendations")
@login_required
def roles():
    guard = require_skills_or_redirect()
    if guard[1]:
        return guard[1]
    (user_skills, resume) = guard[0]

    recs = recommend_roles(user_skills, top_n=8)
    log_activity(current_user, "role_recommendation", f"Top: {recs[0]['title'] if recs else '-'}")
    return render_template("analysis/roles.html", recs=recs, resume=resume)


# ==========================================================================
# Module 9 : Personalized Learning Path
# ==========================================================================
@analysis_bp.route("/learning-path", methods=["GET", "POST"])
@login_required
def learning_path():
    guard = require_skills_or_redirect()
    if guard[1]:
        return guard[1]
    (user_skills, resume) = guard[0]

    from career_data import ROLE_PROFILES
    role_titles = sorted(ROLE_PROFILES.keys())

    # sensible default: the best-matching role from Module 8
    default_role = ""
    recs = recommend_roles(user_skills, top_n=1)
    if recs:
        default_role = recs[0]["title"]

    target = ""
    if request.method == "POST":
        target = (request.form.get("role") or "").strip()
    elif request.args.get("role"):
        target = request.args.get("role")

    path = None
    if target:
        if target not in ROLE_PROFILES:
            flash("Unknown role selected. Please choose from the list.", "warning")
        else:
            path = generate_learning_path(user_skills, target)
            record = LearningPathRecord(
                user_id=current_user.id,
                target_role=path["target_role"],
                readiness=path["readiness"],
                estimated_duration=path["estimated_duration"],
                path_data={
                    "total_new_skills": path["total_new_skills"],
                    "estimated_weeks": path["estimated_weeks"],
                    "phases": [
                        {"no": p["no"], "name": p["name"],
                         "skills": [s["skill"] for s in p["skills"]]}
                        for p in path["phases"]
                    ],
                },
            )
            db.session.add(record)
            db.session.commit()
            log_activity(current_user, "learning_path", f"Target role: {target}")

    return render_template("analysis/learning.html", role_titles=role_titles,
                           target=target, default_role=default_role, path=path, resume=resume)
