"""
Module 4  : Job Description Analysis (paste-a-JD)
Job list & detail pages (with per-job match preview)
Module 10 : Job Recommendation
"""
from flask import Blueprint, render_template, request, redirect, url_for, flash
from flask_login import current_user, login_required

from extensions import db
from models import Job, log_activity
from modules.job_analyzer import analyze_jd
from modules.job_recommender import recommend_jobs
from routes.helpers import get_user_skills

jobs_bp = Blueprint("jobs", __name__)


# --------------------------------------------------------------------------
# Module 4 : analyze any pasted job description
# --------------------------------------------------------------------------
@jobs_bp.route("/analyze-job", methods=["GET", "POST"])
@login_required
def analyze():
    analysis = None
    jd_text = ""
    if request.method == "POST":
        jd_text = (request.form.get("job_description") or "").strip()
        if len(jd_text) < 60:
            flash("Please paste a longer job description (at least ~60 characters).", "warning")
        else:
            analysis = analyze_jd(jd_text)
            log_activity(current_user, "jd_analysis", f"Analyzed JD: {analysis['title']}")
    return render_template("jobs/analyze.html", analysis=analysis, jd_text=jd_text)


# --------------------------------------------------------------------------
# Job browsing
# --------------------------------------------------------------------------
@jobs_bp.route("/jobs")
@login_required
def list_jobs():
    user_skills, resume = get_user_skills()
    jobs = Job.query.filter_by(is_active=True).order_by(Job.created_at.desc()).all()

    scored = None
    if user_skills:
        scored_map = {}
        for r in recommend_jobs(user_skills, jobs):
            scored_map[r["job"].id] = r
        scored = scored_map
    return render_template("jobs/list.html", jobs=jobs, scored=scored, has_skills=bool(user_skills))


@jobs_bp.route("/jobs/<int:job_id>")
@login_required
def detail(job_id):
    job = db.session.get(Job, job_id)
    if job is None:
        flash("Job not found.", "warning")
        return redirect(url_for("jobs.list_jobs"))

    user_skills, _ = get_user_skills()
    match_result = None
    if user_skills and job.skills_json:
        from modules.gap_analyzer import score_match
        match_result = score_match(user_skills, job.skills_json)

    related_jobs = []
    if job.category:
        related_jobs = (Job.query.filter(Job.category == job.category,
                                         Job.is_active.is_(True),
                                         Job.id != job.id)
                        .order_by(Job.created_at.desc()).limit(3).all())
    return render_template("jobs/detail.html", job=job, match_result=match_result,
                           has_skills=bool(user_skills), related_jobs=related_jobs)


# --------------------------------------------------------------------------
# Module 10 : ranked job recommendations
# --------------------------------------------------------------------------
@jobs_bp.route("/job-recommendations")
@login_required
def recommendations():
    user_skills, resume = get_user_skills()
    if not user_skills:
        flash("Upload your resume to unlock personalized job recommendations.", "info")
        return redirect(url_for("resume.upload"))

    jobs = Job.query.filter_by(is_active=True).all()
    ranked = recommend_jobs(user_skills, jobs)
    great_matches = [r for r in ranked if r["match"] >= 60]
    return render_template("jobs/recommendations.html", ranked=ranked,
                           great_matches=great_matches, resume=resume)
