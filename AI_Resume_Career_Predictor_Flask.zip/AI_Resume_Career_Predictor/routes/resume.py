"""
Module 2 : Resume Upload & Parsing
Module 3 : Resume Skill Extraction
"""
import time
from pathlib import Path

from flask import Blueprint, render_template, request, redirect, url_for, flash, abort
from flask_login import current_user, login_required
from werkzeug.utils import secure_filename

from config import Config
from extensions import db
from models import Resume, ExtractedSkill, log_activity
from modules import resume_parser, skill_extractor

resume_bp = Blueprint("resume", __name__)


def _allowed(filename):
    return "." in filename and filename.rsplit(".", 1)[1].lower() in Config.ALLOWED_EXTENSIONS


@resume_bp.route("/upload", methods=["GET", "POST"])
@login_required
def upload():
    if request.method == "POST":
        file = request.files.get("resume")
        if file is None or file.filename == "":
            flash("Please choose a resume file to upload (PDF, DOCX or TXT).", "warning")
            return redirect(request.url)

        if not _allowed(file.filename):
            flash("Unsupported file type. Allowed: PDF, DOCX, TXT.", "danger")
            return redirect(request.url)

        ext = file.filename.rsplit(".", 1)[1].lower()
        original = secure_filename(file.filename)
        stored = f"u{current_user.id}_{int(time.time())}_{original}"

        upload_dir = Path(Config.UPLOAD_FOLDER)
        upload_dir.mkdir(parents=True, exist_ok=True)
        file_path = upload_dir / stored

        # ---- Module 2 : save + parse -----------------------------------
        try:
            file.save(str(file_path))
            with open(str(file_path), "rb") as f:
                if ext == "txt":
                    raw = f.read()
                    text = raw.decode("utf-8", errors="ignore")
                else:
                    text = resume_parser.extract_text(f, ext)
            if ext == "txt" and (not text or len(text.strip()) < 30):
                raise ValueError("The TXT file looks empty. Please upload a resume with content.")
            parsed = resume_parser.parse_resume_text(text)
        except ValueError as ve:
            if file_path.exists():
                file_path.unlink()
            flash(str(ve), "danger")
            return redirect(request.url)
        except Exception:
            if file_path.exists():
                file_path.unlink()
            flash("Could not read this file. Please make sure it is a valid PDF/DOCX/TXT resume.", "danger")
            return redirect(request.url)

        resume = Resume(
            user_id=current_user.id,
            original_filename=original,
            stored_filename=stored,
            file_type=ext,
            raw_text=text[:200000],
            candidate_name=parsed["candidate_name"],
            candidate_email=parsed["candidate_email"],
            candidate_phone=parsed["candidate_phone"],
            experience_years=parsed["experience_years"],
        )
        db.session.add(resume)
        db.session.flush()  # get resume.id

        # ---- Module 3 : skill extraction --------------------------------
        skills_dict, _details = skill_extractor.extract_skills_from_text(text)
        for skill, info in skills_dict.items():
            db.session.add(ExtractedSkill(
                resume_id=resume.id,
                skill_name=skill,
                category=info["category"],
                frequency=info["frequency"],
                proficiency=info["proficiency"],
            ))
        db.session.commit()

        log_activity(current_user, "resume_upload",
                     f"Uploaded '{original}' - {len(skills_dict)} skills extracted")
        flash(f"Resume parsed successfully! {len(skills_dict)} skills extracted.", "success")
        return redirect(url_for("resume.detail", resume_id=resume.id))

    return render_template("resume/upload.html")


@resume_bp.route("/resume/<int:resume_id>")
@login_required
def detail(resume_id):
    resume = db.session.get(Resume, resume_id)
    if resume is None:
        abort(404)
    if resume.user_id != current_user.id and current_user.role != "admin":
        abort(403)

    rows = ExtractedSkill.query.filter_by(resume_id=resume_id).order_by(ExtractedSkill.proficiency.desc()).all()
    details = [
        {"skill": r.skill_name, "category": r.category, "frequency": r.frequency, "proficiency": r.proficiency}
        for r in rows
    ]
    grouped = skill_extractor.skills_by_category(details)
    return render_template("resume/detail.html", resume=resume, grouped=grouped, details=details)


@resume_bp.route("/my-skills")
@login_required
def my_skills():
    from routes.helpers import get_user_skills

    skills, resume = get_user_skills()
    if not resume or not skills:
        flash("Upload a resume to see your extracted skills here.", "info")
        return redirect(url_for("resume.upload"))

    rows = ExtractedSkill.query.filter_by(resume_id=resume.id).order_by(ExtractedSkill.proficiency.desc()).all()
    details = [
        {"skill": r.skill_name, "category": r.category, "frequency": r.frequency, "proficiency": r.proficiency}
        for r in rows
    ]
    grouped = skill_extractor.skills_by_category(details)

    # category distribution for the doughnut chart
    cat_counts = {}
    for d in details:
        cat_counts[d["category"]] = cat_counts.get(d["category"], 0) + 1

    top_skills = details[:8]
    return render_template(
        "resume/skills.html",
        resume=resume, grouped=grouped, details=details,
        cat_labels=list(cat_counts.keys()), cat_values=list(cat_counts.values()),
        top_skills=top_skills,
    )


@resume_bp.route("/resume/<int:resume_id>/delete", methods=["POST"])
@login_required
def delete(resume_id):
    resume = db.session.get(Resume, resume_id)
    if resume is None:
        abort(404)
    if resume.user_id != current_user.id and current_user.role != "admin":
        abort(403)

    # remove the stored file
    try:
        path = Path(Config.UPLOAD_FOLDER) / resume.stored_filename
        if path.exists():
            path.unlink()
    except OSError:
        pass

    db.session.delete(resume)
    db.session.commit()
    flash("Resume deleted.", "info")
    return redirect(url_for("resume.my_skills"))
