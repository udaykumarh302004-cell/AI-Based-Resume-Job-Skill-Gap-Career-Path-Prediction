"""
Module 12 : Admin Module
------------------------
User management, job postings CRUD, resume oversight, sample data seeding
and platform-wide analytics. Admin role required for every route.
"""
from datetime import datetime, timedelta

from flask import Blueprint, render_template, request, redirect, url_for, flash, abort
from flask_login import current_user

from extensions import db
from models import User, Job, Resume, GapAnalysis, LearningPathRecord, CareerPrediction, ActivityLog, log_activity
from routes.helpers import admin_required
from modules.job_analyzer import analyze_jd, weight_skills
from modules.skill_extractor import extract_skills_from_text

admin_bp = Blueprint("admin", __name__)


# --------------------------------------------------------------------------
# Admin dashboard (analytics)
# --------------------------------------------------------------------------
@admin_bp.route("/admin/dashboard")
@admin_required
def dashboard():
    users_count = User.query.count()
    active_users = User.query.filter(User.is_active_user.is_(True)).count()
    jobs_count = Job.query.filter_by(is_active=True).count()
    resumes_count = Resume.query.count()
    analyses_count = GapAnalysis.query.count()
    lps_count = LearningPathRecord.query.count()
    preds_count = CareerPrediction.query.count()

    recent_users = User.query.order_by(User.created_at.desc()).limit(6).all()
    activity = ActivityLog.query.order_by(ActivityLog.created_at.desc()).limit(10).all()

    # jobs per category (bar)
    jobs = Job.query.all()
    cat_counts = {}
    for j in jobs:
        cat_counts[j.category or "Other"] = cat_counts.get(j.category or "Other", 0) + 1

    # most in-demand skills (bar)
    from modules.job_recommender import top_demand_skills
    demand = top_demand_skills(jobs, limit=10)

    # registrations last 7 days (line)
    days, reg_counts = [], []
    now = datetime.now().replace(hour=0, minute=0, second=0, microsecond=0)
    for i in range(6, -1, -1):
        day = now - timedelta(days=i)
        nxt = day + timedelta(days=1)
        c = User.query.filter(User.created_at >= day, User.created_at < nxt).count()
        days.append(day.strftime("%b %d"))
        reg_counts.append(c)

    # average gap score
    gaps = GapAnalysis.query.all()
    avg_match = round(sum(g.match_percentage for g in gaps) / len(gaps), 1) if gaps else 0

    stats = {
        "users": users_count, "active_users": active_users,
        "jobs": jobs_count, "resumes": resumes_count,
        "analyses": analyses_count, "lps": lps_count, "preds": preds_count,
        "avg_match": avg_match,
    }
    return render_template("admin/dashboard.html", stats=stats,
                           recent_users=recent_users, activity=activity,
                           cat_labels=list(cat_counts.keys()), cat_values=list(cat_counts.values()),
                           demand=demand, days=days, reg_counts=reg_counts)


# --------------------------------------------------------------------------
# User management
# --------------------------------------------------------------------------
@admin_bp.route("/admin/users")
@admin_required
def users():
    q = (request.args.get("q") or "").strip().lower()
    query = User.query
    if q:
        query = query.filter((User.name.ilike(f"%{q}%")) | (User.email.ilike(f"%{q}%")))
    users_list = query.order_by(User.created_at.desc()).all()
    resume_counts = {r.user_id: r.c for r in db.session.query(Resume.user_id, db.func.count(Resume.id).label("c")).group_by(Resume.user_id).all()}
    return render_template("admin/users.html", users=users_list, resume_counts=resume_counts, q=q)


@admin_bp.route("/admin/users/<int:user_id>/toggle", methods=["POST"])
@admin_required
def toggle_user(user_id):
    user = db.session.get(User, user_id)
    if user is None:
        abort(404)
    if user.id == current_user.id:
        flash("You cannot deactivate your own admin account.", "warning")
        return redirect(url_for("admin.users"))
    user.is_active_user = not user.is_active_user
    db.session.commit()
    log_activity(current_user, "admin_action",
                 f"{'Activated' if user.is_active_user else 'Deactivated'} user {user.email}")
    flash(f"User {user.email} {'activated' if user.is_active_user else 'deactivated'}.", "success")
    return redirect(url_for("admin.users"))


@admin_bp.route("/admin/users/<int:user_id>/delete", methods=["POST"])
@admin_required
def delete_user(user_id):
    user = db.session.get(User, user_id)
    if user is None:
        abort(404)
    if user.id == current_user.id:
        flash("You cannot delete your own account.", "warning")
        return redirect(url_for("admin.users"))
    if user.role == "admin":
        flash("Admin accounts cannot be deleted from the UI.", "warning")
        return redirect(url_for("admin.users"))

    db.session.delete(user)
    db.session.commit()
    log_activity(current_user, "admin_action", f"Deleted user {user.email}")
    flash(f"User {user.email} and related data deleted.", "info")
    return redirect(url_for("admin.users"))


# --------------------------------------------------------------------------
# Job management (CRUD)
# --------------------------------------------------------------------------
@admin_bp.route("/admin/jobs")
@admin_required
def jobs():
    q = (request.args.get("q") or "").strip().lower()
    query = Job.query
    if q:
        query = query.filter((Job.title.ilike(f"%{q}%")) | (Job.company.ilike(f"%{q}%")))
    jobs_list = query.order_by(Job.created_at.desc()).all()
    return render_template("admin/jobs.html", jobs=jobs_list, q=q)


def _parse_job_form(form):
    """Validate + collect job form fields. Returns (data, errors)."""
    data = {
        "title": (form.get("title") or "").strip(),
        "company": (form.get("company") or "").strip(),
        "location": (form.get("location") or "").strip() or "Not specified",
        "job_type": (form.get("job_type") or "Full-time").strip(),
        "experience_level": (form.get("experience_level") or "Entry level").strip(),
        "category": (form.get("category") or "Software Development").strip(),
        "salary_range": (form.get("salary_range") or "").strip() or "Not disclosed",
        "description": (form.get("description") or "").strip(),
        "skills_text": (form.get("skills_text") or "").strip(),
        "min_experience": form.get("min_experience", type=float) or 0.0,
    }
    errors = []
    if len(data["title"]) < 3:
        errors.append("Job title is required.")
    if len(data["company"]) < 2:
        errors.append("Company name is required.")
    if len(data["description"]) < 60:
        errors.append("Please write a longer job description (60+ characters).")
    return data, errors


def _extract_job_skills(data):
    """Module-4 style extraction of required skills from the JD + skills line."""
    full_text = data["title"] + "\n" + data["description"] + "\n" + data["skills_text"]
    skills_dict, _ = extract_skills_from_text(full_text)
    weighted = weight_skills(skills_dict, full_text)
    # skills explicitly typed in the "required skills" line get a boost
    for token in data["skills_text"].replace(";", ",").split(","):
        token = token.strip()
        if token and token in skills_dict:
            weighted[token] = max(weighted.get(token, 3), 5)
    return weighted


@admin_bp.route("/admin/jobs/new", methods=["GET", "POST"])
@admin_required
def new_job():
    if request.method == "POST":
        data, errors = _parse_job_form(request.form)
        if errors:
            for e in errors:
                flash(e, "danger")
            return render_template("admin/job_form.html", job=None, data=data)

        skills_json = _extract_job_skills(data)
        jd = analyze_jd(data["title"] + "\n" + data["description"] + "\n" + data["skills_text"])
        job = Job(**data, skills_json=skills_json)
        # refine auto-detected level from the form (form wins)
        job.experience_level = data["experience_level"]
        job.min_experience = data["min_experience"] if data["min_experience"] else jd["min_years"]
        job.posted_by = current_user.id
        db.session.add(job)
        db.session.commit()
        log_activity(current_user, "job_created", f"{job.title} @ {job.company}")
        flash(f"Job '{job.title}' posted with {len(skills_json)} extracted skills.", "success")
        return redirect(url_for("admin.jobs"))

    return render_template("admin/job_form.html", job=None, data={})


@admin_bp.route("/admin/jobs/<int:job_id>/edit", methods=["GET", "POST"])
@admin_required
def edit_job(job_id):
    job = db.session.get(Job, job_id)
    if job is None:
        abort(404)

    if request.method == "POST":
        data, errors = _parse_job_form(request.form)
        if errors:
            for e in errors:
                flash(e, "danger")
            return render_template("admin/job_form.html", job=job, data=data)

        for k, v in data.items():
            setattr(job, k, v)
        job.skills_json = _extract_job_skills(data)
        db.session.commit()
        log_activity(current_user, "job_updated", f"{job.title} @ {job.company}")
        flash(f"Job '{job.title}' updated.", "success")
        return redirect(url_for("admin.jobs"))

    data = {k: getattr(job, k) for k in
            ("title", "company", "location", "job_type", "experience_level",
             "category", "salary_range", "description", "skills_text", "min_experience")}
    return render_template("admin/job_form.html", job=job, data=data)


@admin_bp.route("/admin/jobs/<int:job_id>/delete", methods=["POST"])
@admin_required
def delete_job(job_id):
    job = db.session.get(Job, job_id)
    if job is None:
        abort(404)
    db.session.delete(job)
    db.session.commit()
    log_activity(current_user, "job_deleted", f"{job.title} @ {job.company}")
    flash(f"Job '{job.title}' deleted.", "info")
    return redirect(url_for("admin.jobs"))


@admin_bp.route("/admin/jobs/<int:job_id>/toggle", methods=["POST"])
@admin_required
def toggle_job(job_id):
    job = db.session.get(Job, job_id)
    if job is None:
        abort(404)
    job.is_active = not job.is_active
    db.session.commit()
    flash(f"Job '{job.title}' is now {'active' if job.is_active else 'inactive'}.", "success")
    return redirect(url_for("admin.jobs"))


# --------------------------------------------------------------------------
# Resume oversight
# --------------------------------------------------------------------------
@admin_bp.route("/admin/resumes")
@admin_required
def resumes():
    resumes_list = (Resume.query.order_by(Resume.created_at.desc()).limit(100).all())
    return render_template("admin/resumes.html", resumes=resumes_list)


# --------------------------------------------------------------------------
# Seed sample jobs (handy for demos)
# --------------------------------------------------------------------------
@admin_bp.route("/admin/seed-jobs", methods=["POST"])
@admin_required
def seed_jobs():
    from seed_data import SAMPLE_JOBS

    created = 0
    for jd in SAMPLE_JOBS:
        exists = Job.query.filter_by(title=jd["title"], company=jd["company"]).first()
        if exists:
            continue
        skills_json = _extract_job_skills(
            {"title": jd["title"], "description": jd["description"],
             "skills_text": jd.get("skills_text", "")})
        job = Job(**jd, skills_json=skills_json, posted_by=current_user.id)
        db.session.add(job)
        created += 1
    db.session.commit()
    log_activity(current_user, "admin_action", f"Seeded {created} sample jobs")
    flash(f"{created} sample jobs created.", "success")
    return redirect(url_for("admin.jobs"))
