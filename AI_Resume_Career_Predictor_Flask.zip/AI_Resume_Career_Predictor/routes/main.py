"""
Landing page blueprint.
"""
from flask import Blueprint, render_template

main_bp = Blueprint("main", __name__)

MODULES = [
    {"no": 1, "icon": "bi-person-lock", "name": "User Registration & Login", "desc": "Secure signup, login and session management with hashed passwords and role-based access."},
    {"no": 2, "icon": "bi-file-earmark-arrow-up", "name": "Resume Upload & Parsing", "desc": "Upload PDF / DOCX / TXT resumes; the parser extracts contact details and full text."},
    {"no": 3, "icon": "bi-search", "name": "Resume Skill Extraction", "desc": "AI keyword engine scans 100+ skills with aliases and estimates proficiency per skill."},
    {"no": 4, "icon": "bi-binoculars", "name": "Job Description Analysis", "desc": "Paste any JD to extract required skills, seniority, education and experience needs."},
    {"no": 5, "icon": "bi-clipboard-check", "name": "Skill Matching & Gap Analysis", "desc": "Weighted matching between your resume and a job, with a clear skill-gap report."},
    {"no": 6, "icon": "bi-lightbulb", "name": "Skill Gap Recommendation", "desc": "Prioritized recommendations with curated courses for every missing skill."},
    {"no": 7, "icon": "bi-graph-up-arrow", "name": "Career Path Prediction", "desc": "Predicts your current level and future roles across 9 career ladders."},
    {"no": 8, "icon": "bi-person-workspace", "name": "Job Role Recommendation", "desc": "Ranks 25+ roles against your profile and shows the best-fit matches."},
    {"no": 9, "icon": "bi-signpost-split", "name": "Personalized Learning Path", "desc": "Phased week-by-week roadmap from your current skills to any target role."},
    {"no": 10, "icon": "bi-briefcase", "name": "Job Recommendation", "desc": "All open jobs ranked by how well your skills match each one."},
    {"no": 11, "icon": "bi-speedometer2", "name": "Dashboard & Visualization", "desc": "Interactive charts: skill distribution, job match scores and readiness radar."},
    {"no": 12, "icon": "bi-gear", "name": "Admin Module", "desc": "User management, job postings CRUD, resume oversight and platform analytics."},
]


@main_bp.route("/")
def index():
    return render_template("index.html", modules=MODULES)
