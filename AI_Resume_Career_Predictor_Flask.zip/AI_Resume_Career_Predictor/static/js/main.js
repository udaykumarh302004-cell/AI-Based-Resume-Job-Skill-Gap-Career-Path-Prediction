/* ============================================================
   CareerAI - shared front-end helpers
   ============================================================ */

// Auto-dismiss flash messages after 6 seconds
window.addEventListener("DOMContentLoaded", function () {
  document.querySelectorAll(".alert-dismissible").forEach(function (el) {
    setTimeout(function () {
      try {
        bootstrap.Alert.getOrCreateInstance(el).close();
      } catch (e) { /* no-op */ }
    }, 6000);
  });

  // Show selected file name on upload page
  var fileInput = document.getElementById("resumeFile");
  if (fileInput) {
    fileInput.addEventListener("change", function () {
      var nameBox = document.getElementById("fileName");
      if (nameBox && fileInput.files.length) {
        nameBox.innerHTML = "<i class='bi bi-file-earmark-check text-success'></i> " +
          fileInput.files[0].name;
      }
    });
  }
});

// Consistent chart color palette (used by all Chart.js charts)
window.chartPalette = function (n) {
  var base = [
    "#4f46e5", "#f59e0b", "#10b981", "#ef4444", "#0ea5e9",
    "#8b5cf6", "#f97316", "#14b8a6", "#ec4899", "#64748b",
    "#84cc16", "#e11d48"
  ];
  var out = [];
  for (var i = 0; i < n; i++) { out.push(base[i % base.length]); }
  return out;
};
