"""
Module 5 : Skill Matching & Gap Analysis Engine
Module 6 : Skill Gap Recommendation Engine
------------------------------------------------
Module 5 computes a weighted match between a candidate's skill profile and
a job's required skills, with related-skill partial credit.
Module 6 turns the missing skills into prioritized, actionable
recommendations with curated learning resources.
"""
from skills_data import RELATED_SKILLS
from resources_data import get_resources


# ==========================================================================
# Module 5 : matching & gap computation
# ==========================================================================
def score_match(user_skills, required_skills, use_related=True):
    """
    user_skills     : {skill: proficiency 0-100}
    required_skills : {skill: weight 1-5}
    Returns dict with match_percentage, matched, missing, additional, via.
    """
    user_set = set(user_skills.keys())
    required = dict(required_skills or {})
    total_weight = sum(required.values()) or 1

    matched = []
    matched_via = []
    for skill, weight in required.items():
        if skill in user_set:
            matched.append({
                "skill": skill, "weight": weight,
                "proficiency": user_skills[skill], "via": None,
            })
        elif use_related:
            for rel in RELATED_SKILLS.get(skill, []):
                if rel in user_set:
                    matched_via.append({
                        "skill": skill, "weight": weight,
                        "proficiency": user_skills[rel], "via": rel,
                    })
                    break

    matched_skills = {m["skill"] for m in matched}
    via_skills = {m["skill"] for m in matched_via}

    earned = 0.0
    for m in matched:
        earned += m["weight"]
    for m in matched_via:  # partial credit for related skills
        earned += 0.6 * m["weight"]

    missing = [
        {"skill": s, "weight": w}
        for s, w in required.items()
        if s not in matched_skills and s not in via_skills
    ]

    match_pct = round(earned / total_weight * 100, 1)

    if match_pct >= 80:
        verdict = "Excellent match - you are highly aligned with this role"
        verdict_class = "success"
    elif match_pct >= 60:
        verdict = "Good match - close to the role with a few gaps"
        verdict_class = "primary"
    elif match_pct >= 40:
        verdict = "Moderate match - focused upskilling needed"
        verdict_class = "warning"
    else:
        verdict = "Low match - significant upskilling recommended"
        verdict_class = "danger"

    additional = sorted(user_set - set(required.keys()))

    return {
        "match_percentage": match_pct,
        "verdict": verdict,
        "verdict_class": verdict_class,
        "matched": matched,
        "matched_via": matched_via,
        "missing": missing,
        "additional": additional,
        "total_required": len(required),
        "matched_count": len(matched) + len(matched_via),
        "missing_count": len(missing),
    }


# ==========================================================================
# Module 6 : recommendations for missing skills
# ==========================================================================
PRIORITY_BY_WEIGHT = {5: "High", 4: "High", 3: "Medium", 2: "Low", 1: "Low"}


def _why_needed(skill, weight, job_title):
    if weight >= 4:
        return f"{skill} is a core requirement for {job_title} - recruiters will screen for it."
    if weight == 3:
        return f"{skill} is commonly expected for {job_title} and strengthens your application."
    return f"{skill} is a nice-to-have for {job_title} - it can differentiate your profile."


def build_recommendations(missing_skills, job_title="this role"):
    """
    missing_skills : [{skill, weight}, ...] from Module 5
    Returns prioritized recommendation cards with resources.
    """
    ordered = sorted(missing_skills, key=lambda m: -m.get("weight", 3))
    recommendations = []
    for item in ordered:
        skill = item["skill"]
        weight = item.get("weight", 3)
        recommendations.append({
            "skill": skill,
            "weight": weight,
            "priority": PRIORITY_BY_WEIGHT.get(weight, "Medium"),
            "why": _why_needed(skill, weight, job_title),
            "resources": get_resources(skill)[:3],
        })
    return recommendations
