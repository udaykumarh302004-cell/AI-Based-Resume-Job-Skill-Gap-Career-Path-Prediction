# CareerAI - core AI/analysis engine modules
