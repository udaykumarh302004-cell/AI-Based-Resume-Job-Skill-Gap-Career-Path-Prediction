"""
Module 2 : Resume Upload & Parsing Engine
-----------------------------------------
Extracts raw text from PDF / DOCX / TXT resumes and parses
candidate name, email, phone and estimated years of experience.
"""
import re

# --------------------------------------------------------------------------
# Text extraction
# --------------------------------------------------------------------------
def extract_text_from_pdf(file_stream):
    """Extract text from a PDF file-like object using PyPDF2."""
    from PyPDF2 import PdfReader
    reader = PdfReader(file_stream)
    pages = []
    for page in reader.pages:
        try:
            txt = page.extract_text() or ""
        except Exception:
            txt = ""
        pages.append(txt)
    return "\n".join(pages)


def extract_text_from_docx(file_stream):
    """Extract text from a DOCX file-like object using python-docx."""
    from docx import Document
    document = Document(file_stream)
    parts = []
    for para in document.paragraphs:
        if para.text.strip():
            parts.append(para.text)
    for table in document.tables:
        for row in table.rows:
            for cell in row.cells:
                if cell.text.strip():
                    parts.append(cell.text)
    return "\n".join(parts)


def extract_text(file_storage, file_type):
    """Dispatch text extraction by file type. Raises ValueError on failure."""
    if file_type == "pdf":
        text = extract_text_from_pdf(file_storage)
    elif file_type == "docx":
        text = extract_text_from_docx(file_storage)
    elif file_type == "txt":
        raw = file_storage.read()
        text = raw.decode("utf-8", errors="ignore") if isinstance(raw, bytes) else str(raw)
    else:
        raise ValueError(f"Unsupported file type: {file_type}")

    if not text or len(text.strip()) < 30:
        raise ValueError(
            "Could not extract readable text from the file. "
            "If this is a scanned PDF, please upload a text-based PDF, DOCX or TXT resume."
        )
    return text


# --------------------------------------------------------------------------
# Field parsing helpers
# --------------------------------------------------------------------------
EMAIL_RE = re.compile(r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}")
PHONE_RE = re.compile(r"(\+?\d[\d\s\-().]{7,}\d)")
NAME_LABEL_RE = re.compile(r"^\s*name\s*[:\-]\s*([A-Za-z .'-]{2,60})\s*$", re.IGNORECASE)
BAD_NAME_TOKENS = re.compile(
    r"resume|curriculum\s+vitae|cv|profile|email|phone|mobile|address|linkedin|github|@|\d",
    re.IGNORECASE,
)
EXP_YEAR_PATTERNS = [
    re.compile(r"(\d{1,2})\+?\s*years?\s*(?:of)?\s*(?:work\s*)?experience", re.IGNORECASE),
    re.compile(r"experience\s*[:\-]?\s*(\d{1,2})\+?\s*years?", re.IGNORECASE),
    re.compile(r"(\d{1,2})\+?\s*yrs?\s*(?:of)?\s*experience", re.IGNORECASE),
]
EXP_MONTH_PATTERNS = [
    re.compile(r"(\d{1,2})\+?\s*months?\s*(?:of)?\s*(?:work\s*)?experience", re.IGNORECASE),
    re.compile(r"experience\s*[:\-]?\s*(\d{1,2})\+?\s*months?", re.IGNORECASE),
]
SKILL_SECTION_RE = re.compile(
    r"(technical\s+skills|skills?\s*(?:&|and)?\s*(?:abilities|expertise|summary)?|technologies|"
    r"core\s+competencies|tech\s+stack)\s*[:\-]?", re.IGNORECASE)


def parse_name(text):
    lines = [ln.strip() for ln in text.splitlines() if ln.strip()]
    # 1) explicit "Name: X" line
    for ln in lines[:15]:
        m = NAME_LABEL_RE.match(ln)
        if m:
            return m.group(1).strip().title()
    # 2) first clean-looking line near the top
    for ln in lines[:8]:
        if BAD_NAME_TOKENS.search(ln):
            continue
        words = ln.split()
        if 1 < len(words) <= 5 and all(w[0].isalpha() for w in words) and len(ln) <= 48:
            return ln.title()
    # 3) single-word clean line
    for ln in lines[:8]:
        if BAD_NAME_TOKENS.search(ln):
            continue
        if 2 <= len(ln) <= 30 and ln.replace(" ", "").isalpha():
            return ln.title()
    return "Unknown Candidate"


def parse_phone(text):
    m = PHONE_RE.search(text)
    if not m:
        return ""
    phone = re.sub(r"[^\d+]", "", m.group(1))
    if len(phone) < 8:
        return ""
    return phone[:16]


def parse_experience_years(text):
    """Best-effort total experience estimate in years (float)."""
    years = 0.0
    for pat in EXP_YEAR_PATTERNS:
        m = pat.search(text)
        if m:
            years = max(years, float(m.group(1)))
    months = 0.0
    for pat in EXP_MONTH_PATTERNS:
        m = pat.search(text)
        if m:
            months = max(months, float(m.group(1)))
    years = max(years, months / 12.0)
    return min(round(years, 1), 45.0)


def has_skills_section(text):
    return bool(SKILL_SECTION_RE.search(text))


def parse_resume_text(text):
    """Full parse -> dict with contact fields + experience estimate."""
    return {
        "candidate_name": parse_name(text),
        "candidate_email": EMAIL_RE.search(text).group(0) if EMAIL_RE.search(text) else "",
        "candidate_phone": parse_phone(text),
        "experience_years": parse_experience_years(text),
        "has_skills_section": has_skills_section(text),
        "word_count": len(text.split()),
    }
