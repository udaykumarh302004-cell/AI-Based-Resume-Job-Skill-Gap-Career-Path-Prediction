"""
Module 8 : Job Role Recommendation Engine
-----------------------------------------
Recommends the job roles that best fit the user's current skill profile
by scoring it against every role in the knowledge base.
"""
from career_data import ROLE_PROFILES, TRACK_OF_ROLE
from modules.gap_analyzer import score_match


def recommend_roles(user_skills, top_n=8, use_related=True):
    """
    user_skills : {skill: proficiency}
    Returns list of ranked role recommendations:
      [{title, category, track, match, matched, missing, description, typical_experience}]
    """
    results = []
    for title, profile in ROLE_PROFILES.items():
        required = profile["required_skills"]
        res = score_match(user_skills, required, use_related=use_related)
        results.append({
            "title": title,
            "category": profile["category"],
            "track": TRACK_OF_ROLE.get(title, profile["category"]),
            "match": res["match_percentage"],
            "matched": res["matched"] + res["matched_via"],
            "missing": res["missing"],
            "missing_count": res["missing_count"],
            "description": profile["description"],
            "typical_experience": profile.get("typical_experience", "-"),
        })
    results.sort(key=lambda r: -r["match"])
    return results[:top_n]
