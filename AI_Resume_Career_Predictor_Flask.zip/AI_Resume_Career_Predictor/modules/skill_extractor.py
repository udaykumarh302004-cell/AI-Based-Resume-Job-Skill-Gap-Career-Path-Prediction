"""
Module 3 : Resume Skill Extraction Engine
-----------------------------------------
NLP-style keyword matching engine. Scans resume text against the SKILLS_DB
knowledge base (skills + aliases) using word-boundary regex, counts
occurrences and estimates a proficiency score per skill based on:
  - how many times the skill appears
  - qualifier words found near the skill ("advanced", "expert", "basic"...)
  - presence of a dedicated skills section
"""
import re

from skills_data import SKILLS_DB, CASE_SENSITIVE_SKILLS, category_of

# --------------------------------------------------------------------------
# Compile match patterns once
# --------------------------------------------------------------------------
def _compile_patterns():
    patterns = {}
    for skill, (_cat, aliases) in SKILLS_DB.items():
        variants = [skill] + list(aliases)
        escaped = []
        for v in variants:
            v = v.strip()
            if not v:
                continue
            esc = re.escape(v)
            # allow flexible spaces inside multi-word aliases
            esc = esc.replace(r"\ ", r"[\s\-_]+")
            escaped.append(esc)
        if not escaped:
            continue
        body = "|".join(escaped)
        if skill in CASE_SENSITIVE_SKILLS:
            pat = re.compile(r"(?<![A-Za-z0-9])(" + body + r")(?![A-Za-z0-9])")
        else:
            pat = re.compile(r"(?<![A-Za-z0-9])(" + body + r")(?![A-Za-z0-9])", re.IGNORECASE)
        patterns[skill] = pat
    return patterns


_PATTERNS = _compile_patterns()

POSITIVE_QUALIFIERS = re.compile(
    r"\b(expert|expertise|advanced|proficient|strong|senior|extensive|deep|skilled|excellent)\b",
    re.IGNORECASE)
NEGATIVE_QUALIFIERS = re.compile(
    r"\b(basic|basics|beginner|familiar|elementary|introduction|awareness)\b", re.IGNORECASE)

CONTEXT_WINDOW = 45


def extract_skills_from_text(text):
    """
    Core extraction. Returns (skills_dict, details_list)
      skills_dict : {skill_name: {"category", "frequency", "proficiency"}}
      details_list: sorted list for display, same info
    """
    if not text:
        return {}, []

    results = {}
    for skill, pat in _PATTERNS.items():
        matches = list(pat.finditer(text))
        if not matches:
            continue
        frequency = len(matches)
        # qualifier analysis around each occurrence
        pos_hits = 0
        neg_hits = 0
        for m in matches[:12]:  # cap for performance
            start = max(0, m.start() - CONTEXT_WINDOW)
            end = min(len(text), m.end() + CONTEXT_WINDOW)
            window = text[start:end]
            if POSITIVE_QUALIFIERS.search(window):
                pos_hits += 1
            if NEGATIVE_QUALIFIERS.search(window):
                neg_hits += 1

        proficiency = 55 + 10 * min(frequency - 1, 3)  # 55..85 by frequency
        if pos_hits:
            proficiency += min(10, 4 * pos_hits)
        if neg_hits:
            proficiency -= min(20, 8 * neg_hits)
        proficiency = max(30, min(95, proficiency))

        results[skill] = {
            "category": category_of(skill),
            "frequency": frequency,
            "proficiency": int(proficiency),
        }

    details = sorted(
        (
            {"skill": s, **info}
            for s, info in results.items()
        ),
        key=lambda d: (-d["proficiency"], d["skill"]),
    )
    return results, details


def skills_by_category(details_list):
    """Group extracted skill details by category -> {category: [items]}."""
    grouped = {}
    for item in details_list:
        grouped.setdefault(item["category"], []).append(item)
    # sort each group by proficiency desc
    for cat in grouped:
        grouped[cat].sort(key=lambda d: -d["proficiency"])
    return grouped


def user_skill_map(extracted_skills_rows):
    """Convert ExtractedSkill rows -> {skill_name: proficiency}."""
    return {row.skill_name: int(row.proficiency or 60) for row in extracted_skills_rows}
