"""
Module 4 : Job Description Analysis Engine
------------------------------------------
Analyzes a pasted job description or job record:
  - extracts required skills (same engine as Module 3)
  - estimates experience requirement
  - detects seniority level, education requirements and employment type
  - produces weighted skill requirements for matching (Module 5)
"""
import re

from modules.skill_extractor import extract_skills_from_text

SENIORITY_KEYWORDS = {
    "Senior": ["senior", "sr.", "sr ", "lead ", "principal", "staff"],
    "Mid-level": ["mid-level", "mid level", "intermediate", "ii ", "2+"],
    "Entry level": ["junior", "entry level", "entry-level", "intern", "trainee", "fresher", "graduate", "associate"],
    "Lead / Manager": ["manager", "head of", "director", "vp ", "chief", "architect"],
}
EDUCATION_KEYWORDS = {
    "Bachelor's degree": ["bachelor", "b.tech", "btech", "b.e", "bsc", "b.sc", "bca", "undergraduate degree", "be "],
    "Master's degree": ["master", "m.tech", "mtech", "msc", "m.sc", "mca", "mba", "ms "],
    "PhD": ["phd", "ph.d", "doctorate"],
}
EMPLOYMENT_TYPES = {
    "Full-time": ["full-time", "full time", "permanent"],
    "Part-time": ["part-time", "part time"],
    "Internship": ["internship", "intern "],
    "Contract": ["contract", "contractor", "freelance", "c2h"],
}
REMOTE_KEYWORDS = ["remote", "work from home", "wfh", "hybrid"]

EXP_PATTERNS = [
    re.compile(r"(\d{1,2})\s*(?:-|to|–)\s*(\d{1,2})\+?\s*years", re.IGNORECASE),
    re.compile(r"minimum\s*(\d{1,2})\+?\s*years", re.IGNORECASE),
    re.compile(r"(\d{1,2})\+?\s*years?\s*(?:of)?\s*(?:relevant\s*)?experience", re.IGNORECASE),
    re.compile(r"experience\s*[:\-]?\s*(\d{1,2})\+?\s*years", re.IGNORECASE),
    re.compile(r"(\d{1,2})\+?\s*yrs", re.IGNORECASE),
]

TITLE_LINE_RE = re.compile(
    r"^\s*(?:job\s*title|role|position)\s*[:\-]\s*(.+)$", re.IGNORECASE | re.MULTILINE)
COMPANY_LINE_RE = re.compile(
    r"^\s*(?:company|organization|organisation|employer)\s*[:\-]\s*(.+)$", re.IGNORECASE | re.MULTILINE)


def extract_experience_requirement(text):
    """Return (min_years, display_text)."""
    for pat in EXP_PATTERNS:
        m = pat.search(text)
        if m:
            groups = [g for g in m.groups() if g]
            if len(groups) >= 2:  # range like 3-5
                lo = float(groups[0])
                hi = float(groups[1])
                return lo, f"{int(lo)}-{int(hi)} years"
            lo = float(groups[0])
            return lo, f"{int(lo)}+ years"
    return 0.0, "Not specified"


def detect_seniority(text, title=""):
    combined = (title + " " + text[:800]).lower()
    for level, words in SENIORITY_KEYWORDS.items():
        for w in words:
            if w in combined:
                return level
    return "Not specified"


def detect_education(text):
    found = []
    lower = text.lower()
    for edu, words in EDUCATION_KEYWORDS.items():
        for w in words:
            if w in lower:
                found.append(edu)
                break
    return found or ["Not specified"]


def detect_employment_type(text):
    lower = text.lower()
    for etype, words in EMPLOYMENT_TYPES.items():
        for w in words:
            if w in lower:
                return etype
    return "Not specified"


def detect_remote(text):
    lower = text.lower()
    for w in REMOTE_KEYWORDS:
        if w in lower:
            return True
    return False


def guess_title(text):
    m = TITLE_LINE_RE.search(text)
    if m and m.group(1).strip():
        title = m.group(1).strip()
        if len(title) > 60:
            title = re.split(r"[.,;]", title)[0].strip()
        return title[:120]
    for line in text.splitlines():
        line = line.strip()
        if 3 < len(line) <= 80 and not TITLE_LINE_RE.match(line):
            # first short line is usually the title
            if any(k in line.lower() for k in
                   ("developer", "engineer", "analyst", "scientist", "manager",
                    "designer", "architect", "administrator", "consultant", "intern")):
                return line[:120]
    return "Unspecified Job Title"


def guess_company(text):
    m = COMPANY_LINE_RE.search(text)
    if m and m.group(1).strip():
        return m.group(1).strip()[:120]
    return ""


def weight_skills(skills_dict, description):
    """
    Convert extraction frequencies into requirement weights (1-5).
    Skills mentioned more often (or in the first section of the JD)
    are considered more important.
    """
    weighted = {}
    desc_len = max(len(description), 1)
    for skill, info in skills_dict.items():
        freq = info.get("frequency", 1)
        # mentioned once = expected (3), repeatedly = core requirement (4-5)
        weight = 3 + min(freq - 1, 2)  # 3..5
        weighted[skill] = int(weight)
    return weighted


def analyze_jd(text):
    """Full job description analysis -> structured dict."""
    skills_dict, details = extract_skills_from_text(text)
    min_years, years_text = extract_experience_requirement(text)
    analysis = {
        "title": guess_title(text),
        "company": guess_company(text),
        "min_years": min_years,
        "experience_text": years_text,
        "seniority": detect_seniority(text, guess_title(text)),
        "education": detect_education(text),
        "employment_type": detect_employment_type(text),
        "remote_friendly": detect_remote(text),
        "skills_found": details,
        "skill_count": len(details),
        "weighted_skills": weight_skills(skills_dict, text),
        "word_count": len(text.split()),
    }
    return analysis
