"""
Module 10 : Job Recommendation Engine
-------------------------------------
Ranks all active jobs in the database against the user's skill profile
so the user sees the best-fitting openings first.
"""
from modules.gap_analyzer import score_match


def recommend_jobs(user_skills, jobs, top_n=None):
    """
    user_skills : {skill: proficiency}
    jobs        : iterable of Job model rows (active)
    Returns list of dicts sorted by match % (desc):
      [{job, match, matched, missing, verdict, verdict_class}]
    """
    scored = []
    for job in jobs:
        required = job.skills_json or {}
        if not required:
            continue
        res = score_match(user_skills, required)
        scored.append({
            "job": job,
            "match": res["match_percentage"],
            "matched": res["matched"] + res["matched_via"],
            "missing": res["missing"],
            "missing_count": res["missing_count"],
            "verdict": res["verdict"],
            "verdict_class": res["verdict_class"],
        })
    scored.sort(key=lambda r: -r["match"])
    if top_n:
        scored = scored[:top_n]
    return scored


def top_demand_skills(jobs, limit=10):
    """Aggregate most in-demand skills across all jobs (for dashboards)."""
    demand = {}
    for job in jobs:
        for skill, weight in (job.skills_json or {}).items():
            demand[skill] = demand.get(skill, 0) + int(weight or 1)
    ranked = sorted(demand.items(), key=lambda kv: -kv[1])[:limit]
    return ranked
