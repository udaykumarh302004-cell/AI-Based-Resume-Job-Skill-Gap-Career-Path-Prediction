"""
Module 9 : Personalized Learning Path Generator
-----------------------------------------------
Builds a phased, week-by-week learning roadmap that takes the user from
their current skill profile to a target role:
  Phase 1 Foundation  -> weight-5 missing skills (must-haves)
  Phase 2 Core        -> weight-4 missing skills
  Phase 3 Advanced    -> weight 2-3 missing skills
  Phase 4 Portfolio   -> project & branding guidance
Each skill comes with curated resources and an estimated duration.
"""
from career_data import ROLE_PROFILES, get_required_skills
from modules.gap_analyzer import score_match, PRIORITY_BY_WEIGHT
from resources_data import get_resources

WEEKS_BY_WEIGHT = {5: 4, 4: 3, 3: 2, 2: 1, 1: 1}

PHASE_META = {
    1: {
        "name": "Phase 1 - Foundation (must-have skills)",
        "icon": "bi-1-circle-fill",
        "color": "danger",
        "blurb": "Core skills for this role. Master these first - they are non-negotiable in interviews.",
    },
    2: {
        "name": "Phase 2 - Core Professional Skills",
        "icon": "bi-2-circle-fill",
        "color": "warning",
        "blurb": "Important supporting skills that make you job-ready.",
    },
    3: {
        "name": "Phase 3 - Advanced & Differentiators",
        "icon": "bi-3-circle-fill",
        "color": "info",
        "blurb": "Skills that push you from 'qualified' to 'outstanding'.",
    },
    4: {
        "name": "Phase 4 - Portfolio, Projects & Branding",
        "icon": "bi-4-circle-fill",
        "color": "success",
        "blurb": "Prove your skills publicly - this is what converts interviews into offers.",
    },
}


def _phase_for_weight(weight):
    if weight >= 5:
        return 1
    if weight == 4:
        return 2
    return 3


def generate_learning_path(user_skills, target_role):
    """
    user_skills : {skill: proficiency}
    target_role : role title present in ROLE_PROFILES
    Returns dict {target_role, readiness, phases, totals...}
    """
    profile = ROLE_PROFILES.get(target_role)
    if profile is None:
        return None

    required = get_required_skills(target_role)
    res = score_match(user_skills, required)
    missing = res["missing"]  # [{skill, weight}]
    missing.sort(key=lambda m: (-m.get("weight", 3), m["skill"]))

    phases = {1: [], 2: [], 3: []}
    total_weeks = 0
    for item in missing:
        skill = item["skill"]
        weight = item.get("weight", 3)
        weeks = WEEKS_BY_WEIGHT.get(weight, 2)
        total_weeks += weeks
        phases[_phase_for_weight(weight)].append({
            "skill": skill,
            "weight": weight,
            "priority": PRIORITY_BY_WEIGHT.get(weight, "Medium"),
            "weeks": weeks,
            "resources": get_resources(skill)[:3],
        })

    portfolio_ideas = [
        f"Build a capstone project that combines at least 3 core {target_role} skills and publish it on GitHub.",
        f"Create a portfolio page / README case-study explaining your {target_role} project end to end.",
        f"Update your resume and LinkedIn headline towards '{target_role}' using the exact skill keywords.",
        "Ask for mock interviews / feedback from peers and iterate on weak areas.",
    ]

    return {
        "target_role": target_role,
        "role_description": profile["description"],
        "readiness": res["match_percentage"],
        "matched_count": res["matched_count"],
        "missing_count": res["missing_count"],
        "phases": [
            {"no": no, **PHASE_META[no], "skills": phases[no]}
            for no in (1, 2, 3)
        ] + [
            {"no": 4, **PHASE_META[4], "skills": [], "portfolio_ideas": portfolio_ideas},
        ],
        "total_new_skills": len(missing),
        "estimated_weeks": total_weeks,
        "estimated_duration": (f"~{total_weeks} weeks (~{max(1, round(total_weeks / 4.3))} months) "
                               "at 8-10 hrs/week") if total_weeks else "You are ready - focus on applications!",
        "have_skills": [m["skill"] for m in res["matched"]],
    }
