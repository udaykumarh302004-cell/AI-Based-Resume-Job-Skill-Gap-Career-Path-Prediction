"""
Module 7 : Career Path Prediction Engine
----------------------------------------
Predicts the user's current career level and future progression path:
 1. Scores the skill profile against every known role (weighted match).
 2. Picks the best-fitting career track.
 3. Walks the track ladder to estimate the CURRENT level (readiness +
    experience based) and the NEXT role to target.
 4. Estimates a promotion timeline and the exact skills to close.
"""
from career_data import ROLE_PROFILES, CAREER_TRACKS, TRACK_OF_ROLE, get_required_skills
from modules.gap_analyzer import score_match
from resources_data import get_resources

READINESS_THRESHOLD = 55  # % needed to be considered "at" a level


def _readiness(user_skills, title, use_related=True):
    required = get_required_skills(title)
    if not required:
        return 0.0, []
    res = score_match(user_skills, required, use_related=use_related)
    return res["match_percentage"], res["missing"]


def _level_allowed_by_experience(years):
    if years is None or years <= 0:
        return 1
    if years < 2:
        return 1
    if years < 5:
        return 2
    if years < 8:
        return 3
    if years < 12:
        return 4
    return 5


def _promotion_timeline(readiness_of_next):
    if readiness_of_next >= 75:
        return "3-6 months (you are almost there)"
    if readiness_of_next >= 55:
        return "6-12 months with focused upskilling"
    if readiness_of_next >= 35:
        return "1-2 years of consistent upskilling"
    return "2+ years - a longer-term goal for now"


def _track_best_scores(user_skills):
    """Score user against ALL roles -> sorted list of dicts."""
    results = []
    for title, profile in ROLE_PROFILES.items():
        pct, missing = _readiness(user_skills, title)
        results.append({
            "title": title,
            "category": profile["category"],
            "match": pct,
            "missing_count": len(missing),
        })
    results.sort(key=lambda r: -r["match"])
    return results


def predict_career_path(user_skills, experience_years=None):
    """
    Main entry (Module 7).
    user_skills      : {skill: proficiency}
    experience_years : float or None
    Returns a rich dict for rendering + storing in CareerPrediction.
    """
    all_scores = _track_best_scores(user_skills)
    best_role = all_scores[0]["title"] if all_scores else None

    # locate the ladder containing the best role (fallback: software dev)
    track = None
    if best_role and best_role in TRACK_OF_ROLE:
        track_name = TRACK_OF_ROLE[best_role]
        track = next((t for t in CAREER_TRACKS if t["track"] == track_name), None)
    if track is None:
        track = CAREER_TRACKS[0]

    # compute readiness for every ladder step
    ladder = []
    level_idx = 0
    years_cap = _level_allowed_by_experience(experience_years)
    for step in track["roles"]:
        pct, missing = _readiness(user_skills, step["title"], use_related=False)
        step_info = {
            "title": step["title"],
            "level": step["level"],
            "years": step["years"],
            "readiness": pct,
            "missing": missing,
        }
        ladder.append(step_info)
        if pct >= READINESS_THRESHOLD and step["level"] <= max(years_cap, 1):
            level_idx = step["level"] - 1

    # never higher than last rung
    level_idx = min(level_idx, len(ladder) - 1)
    current = ladder[level_idx]
    nxt = ladder[level_idx + 1] if level_idx + 1 < len(ladder) else None

    # alternatives: best role of each OTHER track
    alternatives = []
    seen_tracks = {track["track"]}
    for r in all_scores:
        t = TRACK_OF_ROLE.get(r["title"])
        if t and t not in seen_tracks:
            alternatives.append(r)
            seen_tracks.add(t)
        if len(alternatives) >= 4:
            break

    prediction = {
        "best_track": track["track"],
        "track_icon": track.get("icon", "bi-briefcase"),
        "best_role_match": all_scores[0]["match"] if all_scores else 0,
        "current_level": current["level"],
        "current_title": current["title"],
        "current_readiness": current["readiness"],
        "next_title": nxt["title"] if nxt else "Career peak reached in this track",
        "next_readiness": nxt["readiness"] if nxt else 100.0,
        "next_missing": nxt["missing"] if nxt else [],
        "next_timeline": _promotion_timeline(nxt["readiness"]) if nxt else "-",
        "ladder": ladder,
        "top_roles": all_scores[:8],
        "alternatives": alternatives,
        "experience_years": experience_years or 0,
    }
    return prediction


def next_step_resources(missing):
    """Resource cards for closing the gap to the NEXT role (Module 7 UI)."""
    cards = []
    for item in missing[:6]:
        cards.append({"skill": item["skill"], "resources": get_resources(item["skill"])[:2]})
    return cards
